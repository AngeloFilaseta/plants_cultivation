2015-08-20 these examples are retrofitted from version 0.1.20 which supports more errors.

